<?php

namespace App\Services;

use illuminate\Support\Facades\Request;

class Charge
{

    public function __construct()
    {
        //
    }

    public function collect()
    {
        //
    }
  
}
