<?php

namespace App\SMS;



class OTP extends SMS
{
    //
}
