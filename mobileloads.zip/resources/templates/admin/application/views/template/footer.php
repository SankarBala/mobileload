<footer>
    <div class="footer-area">
        <p>© Copyright 2018. All right reserved.</p>
    </div>
</footer>