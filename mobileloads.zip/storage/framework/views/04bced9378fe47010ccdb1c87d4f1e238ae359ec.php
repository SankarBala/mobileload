

<?php $__env->startSection('title', 'title'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mobileload\resources\views/termsOfUse.blade.php ENDPATH**/ ?>