<div class="sidebar-menu">
    <div class="main-menu">
        <div class="menu-inner">
            <div class="sidebar-header">
                <div class="logo">
                    
                </div>
                <div class="logo">
                    <img src="<?php echo e(asset('backend/images/profile/john_doe.jpg')); ?>" class="img-profile img-rounded"
                        alt="logo">
                </div>
                <div class="profile">
                    <div class="profile-name text-center">John Doe</div>
                    <div class="profile-title text-center">Administrator</div>
                    <div class="profile-line"></div>
                </div>
            </div>
            <nav>
                <ul class="metismenu" id="menu">
                    

                    <li><a href=""><i class="ti-layout-sidebar-left"></i> <span>Dashboard</span></a></li>
                  



                </ul>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\mobileload\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>