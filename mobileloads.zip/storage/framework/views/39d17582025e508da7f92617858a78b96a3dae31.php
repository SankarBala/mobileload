<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">
    <link href="<?php echo e(asset('frontend/images/favicon.png')); ?>" rel="icon" />
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <meta name="description" content="Quickai - Recharge & Bill Payment, Booking HTML5 Template">
    <meta name="author" content="harnishdesign.net">

    <!-- Web Fonts -->
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900'
        type='text/css'>

    <!-- Stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/vendor/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('frontend/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('frontend/vendor/owl.carousel/assets/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/stylesheet.css')); ?>" />
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>

    <!-- Preloader -->
    
    <!-- Preloader End -->

    <!-- Document Wrapper -->
    <div id="main-wrapper">

        <!-- Header -->
        <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- Header end -->

        <!-- Content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Content end -->

        <!-- Footer -->
        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- Footer end -->

    </div>
    <!-- Document Wrapper end -->

    <!-- Back to Top -->
    <a id="back-to-top" data-toggle="tooltip" title="Back to Top" href="javascript:void(0)"><i
            class="fa fa-chevron-up"></i></a>
    <!-- Back to Top End -->

    <!-- Modals -->
    <?php if (isset($component)) { $__componentOriginal3962b3114571e4e0c188edb69dfd72e41b4d2ab9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\Login::class, []); ?>
<?php $component->withName('modal.login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3962b3114571e4e0c188edb69dfd72e41b4d2ab9)): ?>
<?php $component = $__componentOriginal3962b3114571e4e0c188edb69dfd72e41b4d2ab9; ?>
<?php unset($__componentOriginal3962b3114571e4e0c188edb69dfd72e41b4d2ab9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginale99e2d017c68d16ed5329d471d904217ec8d7d1a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\Register::class, []); ?>
<?php $component->withName('modal.register'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale99e2d017c68d16ed5329d471d904217ec8d7d1a)): ?>
<?php $component = $__componentOriginale99e2d017c68d16ed5329d471d904217ec8d7d1a; ?>
<?php unset($__componentOriginale99e2d017c68d16ed5329d471d904217ec8d7d1a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala4792b8056f7ba8a0b7c54238fa56f9eb473566f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\ForgotPassword::class, []); ?>
<?php $component->withName('modal.forgot-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginala4792b8056f7ba8a0b7c54238fa56f9eb473566f)): ?>
<?php $component = $__componentOriginala4792b8056f7ba8a0b7c54238fa56f9eb473566f; ?>
<?php unset($__componentOriginala4792b8056f7ba8a0b7c54238fa56f9eb473566f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal45547eafceea8638a33bcbbeebd6a0a01364e20b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\NewPassword::class, []); ?>
<?php $component->withName('modal.new-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal45547eafceea8638a33bcbbeebd6a0a01364e20b)): ?>
<?php $component = $__componentOriginal45547eafceea8638a33bcbbeebd6a0a01364e20b; ?>
<?php unset($__componentOriginal45547eafceea8638a33bcbbeebd6a0a01364e20b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal70590417f6ef357718a38fc05851caf334ae69c2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\Otp::class, []); ?>
<?php $component->withName('modal.otp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal70590417f6ef357718a38fc05851caf334ae69c2)): ?>
<?php $component = $__componentOriginal70590417f6ef357718a38fc05851caf334ae69c2; ?>
<?php unset($__componentOriginal70590417f6ef357718a38fc05851caf334ae69c2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf2eed8cc8d50c92fa32b362c0b8282dc824a3e23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal\ViewPlan::class, []); ?>
<?php $component->withName('modal.view-plan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2eed8cc8d50c92fa32b362c0b8282dc824a3e23)): ?>
<?php $component = $__componentOriginalf2eed8cc8d50c92fa32b362c0b8282dc824a3e23; ?>
<?php unset($__componentOriginalf2eed8cc8d50c92fa32b362c0b8282dc824a3e23); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- Modals end -->

    <!-- Script -->
    <script src="<?php echo e(asset('frontend/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/theme.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH D:\Laravel\mobileload\resources\views/layouts/app.blade.php ENDPATH**/ ?>