<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('backend/images/icon/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/metisMenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/slicknav.min.css')); ?>">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css"
        media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/typography.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/default-css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/responsive.css')); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
    <!-- modernizr css -->
    <script src="<?php echo e(asset('backend/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <?php if (isset($component)) { $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Sidebar::class, []); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d)): ?>
<?php $component = $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d; ?>
<?php unset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <?php if (isset($component)) { $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Header::class, []); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757)): ?>
<?php $component = $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757; ?>
<?php unset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <?php if (isset($component)) { $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Footer::class, []); ?>
<?php $component->withName('admin.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4)): ?>
<?php $component = $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4; ?>
<?php unset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->

    <!-- jquery latest version -->
    <script src="<?php echo e(asset('backend/js/vendor/jquery-2.2.4.min.js')); ?>"></script>
    <!-- bootstrap 4 js -->
    <script src="<?php echo e(asset('backend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/jquery.slicknav.min.js')); ?>"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <!-- start amcharts -->
    <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
    <script src="https://www.amcharts.com/lib/3/ammap.js"></script>
    <script src="https://www.amcharts.com/lib/3/maps/js/worldLow.js"></script>
    <script src="https://www.amcharts.com/lib/3/serial.js"></script>
    <script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
    <script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
    <!-- all line chart activation -->
    <script src="<?php echo e(asset('backend/js/line-chart.js')); ?>"></script>
    <!-- all pie chart -->
    <script src="<?php echo e(asset('backend/js/pie-chart.js')); ?>"></script>
    <!-- all bar chart -->
    <script src="<?php echo e(asset('backend/js/bar-chart.js')); ?>"></script>
    <!-- all map chart -->
    <script src="<?php echo e(asset('backend/js/maps.js')); ?>"></script>
    <!-- others plugins -->
    <script src="<?php echo e(asset('backend/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/scripts.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH D:\Laravel\mobileload\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>