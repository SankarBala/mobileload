<?php $__env->startSection('content'); ?>

    <!-- Login Modal -->
    <div>
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <div class="modal-body py-4 px-0">
                    <!-- Login Form -->
                    <div class="row">
                        <div class="col-11 col-md-10 mx-auto">
                            <ul class="nav nav-tabs nav-justified mb-4" role="tablist">
                                <li class="nav-item"> <a class="nav-link text-5 line-height-3 active">Login</a> </li>
                                <li class="nav-item"> <a class="nav-link text-5 line-height-3"
                                        href="<?php echo e(route('register')); ?>">Sign Up</a>
                                </li>
                            </ul>
                            <p class="text-4 font-weight-300 text-muted text-center mb-4">We are glad to see you again!
                            </p>
                            <form id="loginForm" method="post" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" required placeholder="Email"
                                        value="<?php echo e(old('email')); ?>" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" required
                                        placeholder="Password" autocomplete="off" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row my-4">
                                    <div class="col">
                                        <div class="form-check text-2 custom-control custom-checkbox">
                                            <input id="remember-me" name="remember" class="custom-control-input"
                                                type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                                            <label class="custom-control-label" for="remember-me">Remember Me</label>
                                        </div>
                                    </div>
                                    <div class="col text-2 text-right"><a class="btn-link" href="" data-toggle="modal"
                                            data-target="#forgot-password-modal" data-dismiss="modal">Forgot Password
                                            ?</a></div>
                                </div>
                                <button class="btn btn-primary btn-block my-4" type="submit">Login</button>
                            </form>
                            <?php if (isset($component)) { $__componentOriginal3826773a295cef8de2f3074cda288da3a1204464 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Auth\SocialAuth::class, []); ?>
<?php $component->withName('auth.social-auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3826773a295cef8de2f3074cda288da3a1204464)): ?>
<?php $component = $__componentOriginal3826773a295cef8de2f3074cda288da3a1204464; ?>
<?php unset($__componentOriginal3826773a295cef8de2f3074cda288da3a1204464); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <p class="text-2 text-center mb-0">New to MobileLoad? <a class="btn-link"
                                    href="<?php echo e(route('register')); ?>">Sign Up</a></p>
                        </div>
                    </div>
                    <!-- Login Form End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Login Modal End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mobileload\resources\views/auth/login.blade.php ENDPATH**/ ?>