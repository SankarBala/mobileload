

<?php $__env->startSection('title', 'Support Center'); ?>

<?php $__env->startSection('content'); ?>
Support page content here.
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mobileload\resources\views/support.blade.php ENDPATH**/ ?>