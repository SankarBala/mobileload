<div>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
</div><div class="sidebar-menu">
    <div class="main-menu">
        <div class="menu-inner">
            <div class="sidebar-header">
                <div class="logo">
                    
                </div>
                <div class="logo">
                    <img src="<?php echo e(Storage::url($user->profile->photo)); ?>" class="img-profile img-rounded"
                        alt="logo">
                </div>
                <div class="profile">
                    <div class="profile-name text-center"><?php echo e($user->name); ?></div>
                    
                    <div class="profile-line"></div>
                </div>
            </div>
            <nav>
                <ul class="metismenu" id="menu">
                    
                    <li><a href="<?php echo e(route('client.home')); ?>"><i class="ti-dashboard"></i> <span>Dashboard</span></a></li>
                    <li><a href="<?php echo e(route('client.mobile_recharge')); ?>"><i class="ti-mobile"></i> <span>Mobile Recharge</span></a></li>
                    <li><a href="<?php echo e(route('client.sms')); ?>"><i class="ti-envelope"></i> <span>Send SMS</span></a></li>
                    <li><a href="<?php echo e(route('client.profile')); ?>"><i class="ti-user"></i> <span>Profile</span></a></li>
                    <li><a href="<?php echo e(route('client.setting')); ?>"><i class="ti-settings"></i> <span>Settings</span></a></li>
                  
                  
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\mobileload\resources\views/components/client/sidebar.blade.php ENDPATH**/ ?>