<?php $__env->startSection('content'); ?>

    <!-- Sign Up Modal -->
    <div id="" class="">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <div class="modal-body py-4 px-0">

                    <!-- Sign Up Form-->
                    <div class="row">
                        <div class="col-11 col-md-10 mx-auto">
                            <ul class="nav nav-tabs nav-justified mb-4" role="tablist">
                                <li class="nav-item"> <a class="nav-link text-5 line-height-3" href="<?php echo e(route('login')); ?>">Log In</a>
                                </li>
                                <li class="nav-item"> <a class="nav-link text-5 line-height-3 active">Sign Up</a> </li>
                            </ul>
                            <p class="text-4 font-weight-300 text-muted text-center mb-4">Looks like you're new here!
                            </p>
                            <form id="signupForm" method="post" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="text" class="form-control border-2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="name" required placeholder="Your Name" value="<?php echo e(old('name')); ?>"
                                        autocomplete="name" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control border-2 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email" required placeholder="Email" value="<?php echo e(old('email')); ?>"
                                        autocomplete="email" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="password"
                                        class="form-control border-2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="password" required placeholder="Password" autocomplete="new-password" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control border-2" name="password_confirmation"
                                        required placeholder="Confirm Password" autocomplete="new-password" />
                                </div>
                                <div class="form-group my-4">
                                    <div class="form-check text-2 custom-control custom-checkbox">
                                        <input id="agree" name="agreement" class="custom-control-input" type="checkbox"
                                            onclick="agreementCheck()" />
                                        <label class="custom-control-label" for="agree">I agree to the <a
                                                href="<?php echo e(route('fallback', 'terms')); ?>">Terms</a>
                                            and <a href="<?php echo e(route('privacyPolicy')); ?>">Privacy Policy</a>.</label>
                                    </div>
                                    <?php $__errorArgs = ['agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button id="submitRegister" class="btn btn-primary btn-block my-4" type="submit"
                                    disabled>Sign Up</button>
                            </form>
                            <?php if (isset($component)) { $__componentOriginal3826773a295cef8de2f3074cda288da3a1204464 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Auth\SocialAuth::class, []); ?>
<?php $component->withName('auth.social-auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3826773a295cef8de2f3074cda288da3a1204464)): ?>
<?php $component = $__componentOriginal3826773a295cef8de2f3074cda288da3a1204464; ?>
<?php unset($__componentOriginal3826773a295cef8de2f3074cda288da3a1204464); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <p class="text-2 text-center mb-0">Already have an account? <a class="btn-link"
                                    href="<?php echo e(route('login')); ?>">Log In</a></p>
                        </div>
                    </div>
                    <!-- Sign Up Form End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Sign Up Modal End -->

    <?php $__env->startPush('script'); ?>
        <script type="text/javascript">
            function agreementCheck() {
                let agree = document.getElementById("agree");
                let submitRegister = document.getElementById("submitRegister");

                if (agree.checked == true) {
                    submitRegister.disabled = false;
                } else {
                    submitRegister.disabled = true;
                }
            }

        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mobileload\resources\views/auth/register.blade.php ENDPATH**/ ?>