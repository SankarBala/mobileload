 <!-- Modal Dialog - View Plans -->
 <div id="view-plans" class="modal fade" role="dialog" aria-hidden="true">
     <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title">Browse Plans</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span
                         aria-hidden="true">×</span> </button>
             </div>
             <div class="modal-body">
                 <form class="form-row mb-4 mb-sm-2" method="post">
                     <div class="col-12 col-sm-6 col-lg-4">
                         <div class="form-group">
                             <select class="custom-select" required="">
                                 <option value="">Select Your Operator</option>
                                 <option>Grameenphone</option>
                                 <option>Banglalink</option>
                                 <option>Airtel</option>
                                 <option>Robi</option>
                                 <option>Teletalk</option>
                             </select>
                         </div>
                     </div>
                     <div class="col-12 col-sm-6 col-lg-4">
                         <div class="form-group">
                             <select class="custom-select" required="">
                                 <option value="">All Plans</option>
                                 <option>Talktime</option>
                                 <option>SMS</option>
                                 <option>Data</option>
                             </select>
                         </div>
                     </div>
                     <div class="col-12 col-sm-6 col-lg-3">
                         <button class="btn btn-primary btn-block" type="submit">View Plans</button>
                     </div>
                 </form>
                 <div class="plans">
                     <hr class="my-4">
                     <div class="row align-items-center">
                         <div class="col-4 col-lg-2 text-5 text-primary text-center">Grameenphone</div>
                         <div class="col-4 col-lg-2 text-5 text-primary text-center">৳50<span
                                 class="text-1 text-muted d-block">Amount</span></div>
                         <div class="col-4 col-lg-2 text-3 text-center">1099<span
                                 class="text-1 text-muted d-block">Talktime</span></div>
                         <div class="col-4 col-lg-2 text-3 text-center">356 Days<span
                                 class="text-1 text-muted d-block">Validity</span></div>
                         <div class="col-7 col-lg-3 my-2 my-lg-0 text-1 text-muted">
                             <h6>Full Talktime</h6>
                         </div>
                         <div class="col-5 col-lg-3 my-2 my-lg-0 text-right text-lg-center">
                             <button class="btn btn-sm btn-outline-primary shadow-none text-nowrap"
                                 type="submit">Recharge</button>
                         </div>
                     </div>
                     <hr class="my-4">
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- Modal Dialog - View Plans end -->

 <?php $__env->startPush('script'); ?>
     <script type="text/javascript">
        //  $(document).ready(function() {
        //      $('body').click(function() {
        //          $.ajax({
        //              url: "https://bdsmartpay.com/sms/operatorplans.php",
        //              type: "GET",
        //              success: function(data, status) {
        //                  console.log(data);
        //              }
        //          }).fail(function(res) {
        //              console.log(res.responseJSON.message);
        //          });
        //      });
        //  });

     </script>
 <?php $__env->stopPush(); ?>
<?php /**PATH D:\Laravel\mobileload\resources\views/components/modal/view-plan.blade.php ENDPATH**/ ?>