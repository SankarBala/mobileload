

<?php $__env->startSection('title', 'Mobile Recharge'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <!-- page title area start -->
    <div class="page-title-area">
        <div class="row align-items-center">
            <div class="col-sm-12">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Recharge</h4>
                    <ul class="breadcrumbs pull-left">
                        <li><a href="">Home</a></li>
                        <li><span>Recharge</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- page title area end -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="container-fluid py-4">
        <div class="bg-white shadow-md rounded p-4">
            <div class="row">

                <!-- Mobile Recharge -->

                <div class="col-lg-4 mb-4 mb-lg-0">

                    <form id="recharge-bill" method="post" action="<?php echo e(route('client.recharge')); ?>">

                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input id="prepaid" name="accountType" class="custom-control-input" checked="" required
                                    type="radio" value="Prepaid">
                                <label class="custom-control-label" for="prepaid">Prepaid</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input id="postpaid" name="accountType" class="custom-control-input" required type="radio"
                                    value="Postpaid">
                                <label class="custom-control-label" for="postpaid">Postpaid</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" data-bv-field="number" id="mobileNumber" required
                                placeholder="Enter Mobile Number" name="mobileNumber">
                            <?php $__errorArgs = ['mobileNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <select class="custom-select" id="operator" required="" name="operator">
                                <option>Select Your Operator</option>
                                <option value="GP">Grameenphone</option>
                                <option value="BL">Banglalink</option>
                                <option value="AT">Airtel</option>
                                <option value="RB">Robi</option>
                                <option value="TT">Teletalk</option>
                                <option value="GP ST">Skitto (GP)</option>
                            </select>
                            <?php $__errorArgs = ['operator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group input-group">
                            <div class="input-group-prepend"> <span class="input-group-text">&nbsp; ৳
                                    &nbsp;</span> </div>

                            <input class="form-control" id="amount" placeholder="Enter Amount" required type="number"
                                name="amount" />
                        </div>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button class="btn btn-primary btn-block" type="submit">Recharge</button>

                    </form>
                </div>
                <!-- Mobile Recharge end -->

                <div class="col-lg-8">
                    <?php if(Session::has('message')): ?>
                        <h4 class="text-info"><?php echo e(Session::get('message')); ?></h4>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mobileload\resources\views/client/mobile.blade.php ENDPATH**/ ?>