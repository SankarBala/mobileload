  <div class="d-flex align-items-center my-3">
      <hr class="flex-grow-1">
      <span class="mx-2 text-2 text-muted">Or Use Social Profile</span>
      <hr class="flex-grow-1">
  </div>
  <div class="d-flex  flex-column align-items-center mb-3">
      <ul class="social-icons social-icons-colored social-icons-circle">
          <li class="social-icons-facebook"><a href="#" data-toggle="tooltip"
                  data-original-title="Use Facebook"><i class="fab fa-facebook-f"></i></a>
          </li>
          <li class="social-icons-twitter"><a href="#" data-toggle="tooltip"
                  data-original-title="Use Twitter"><i class="fab fa-twitter"></i></a>
          </li>
          <li class="social-icons-google"><a href="#" data-toggle="tooltip" data-original-title="Use Google"><i
                      class="fab fa-google"></i></a>
          </li>
          <li class="social-icons-linkedin"><a href="#" data-toggle="tooltip"
                  data-original-title="Use Linkedin"><i class="fab fa-linkedin-in"></i></a></li>
      </ul>
  </div>
<?php /**PATH D:\Laravel\mobileload\resources\views/components/auth/social-auth.blade.php ENDPATH**/ ?>