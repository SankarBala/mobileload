<?php
return [
    'server_url' => env('SHURJOPAY_SERVER_URL'),
    'merchant_username' => env('MERCHANT_USERNAME'),
    'merchant_password' => env('MERCHANT_PASSWORD'),
    'merchant_key_prefix' => env('MERCHANT_KEY_PREFIX'),
];
